var Command = function(input, prompt) {
    this.input = input;
    this.prompt = '';
    this.name = '';
    this.options = {};
    this.content = [];
    // parse prompt
    this.PrompParser(prompt);
    // parse input
    this.InputParser(input);
}

Command.prototype.PrompParser = function(prompt) {
    if (prompt.length > 1) {
        this.name = prompt.substring(1).trim();
        this.prompt = this.name;
    }
}

Command.prototype.displayCommand = function(terminal, commands, cmd) {
    var autocompletions = [];
    for (let key in commands) {
        if (key == cmd) {
            terminal.input.val(terminal.input.val()+cmd+" ");
            let cmdInstance = this.getCmdInstance(commands[key]);
            if (cmdInstance && cmdInstance.hasOwnProperty('subCmds')) {
                let subCmd = this.content.length > 0 ? this.content.shift() : '';
                this.displayCommand(terminal, cmdInstance.subCmds, subCmd);
            } else if (this.content.length > 0) {
                terminal.input.val(terminal.input.val()+this.content.join(' '));
            }
            break;
        } else if (key.startsWith(cmd)) {
            autocompletions.push(key);
        }
    }
    if (autocompletions.length == 1) {
        terminal.input.val(terminal.input.val()+autocompletions[0]+" ");
    } else if (autocompletions.length > 1) {
        terminal.displayOutput(autocompletions.join(', '));
        terminal.input.val(this.input);
    }
}

Command.prototype.GetInputArgs = function() {
    return {
        input: this.input,
        cmd: this.name,
        options: this.options,
        content: this.content,
        prompt: this.prompt
    }
}

Command.prototype.TabCompleteSystem = function(terminal) {
    terminal.input.val('');
    this.displayCommand(terminal, terminal.all_commands, this.name);
}

Command.prototype.TabComplete = function(terminal, from_remote) {
    var self = this;
    var cmdInstance = this.getCmdInstance(terminal.all_commands[this.name]);
    if (cmdInstance && typeof cmdInstance.TabComplete == 'function') {
        // 判断命令是当前页面执行还是远端执行
        if (!from_remote && cmdInstance.hasOwnProperty('config') && cmdInstance.config.hasOwnProperty('site')) {
            api_send_message({
                type: 'exec-remote-tab',
                config: cmdInstance.config,
                item: {
                    'showType': 'background',
                    'input': self.input,
                }, 
                callback: function(result) {
                    var message = result && result.hasOwnProperty('data') ? result.data : [];
                    terminal.displayOutput(terminal.formateOutput(message, from_remote));
                    terminal.input.val(self.input);
                }
            });
        } else {
            var result =  cmdInstance.TabComplete(this.GetInputArgs());
            terminal.input.val(self.input);
            return result;
        }
    }
    return [];
}

Command.prototype.getCmdInstance = function(cmdDefine) {
    let cmdInstance = null;
    try {
        if (typeof cmdDefine == 'function') {
            cmdInstance = (new cmdDefine());
        } else if (typeof cmdDefine == 'string' && cmdDefine.trim()) {
            cmdInstance = eval('new '+cmdDefine+'()');
        } else {
            cmdInstance = cmdDefine;
        }
    } catch (e) {}
    
    return cmdInstance;
}

Command.prototype.Exec = function(terminal, from_remote, callback) {
    var self = this;
    var shown_input = this.input;
    if (terminal.input.attr('type') === 'password') {
        shown_input = new Array(shown_input.length + 1).join("•");
    }
    
    terminal.displayInput(shown_input);
    terminal.validator(self.name);

    let cmdInstance = self.getCmdInstance(terminal.all_commands[self.name]);
    // change simple options to normal options
    this.options = self.TransferSimpleOptions(cmdInstance);
    var exec = function(instance, exec_type) {
        // exec this cmd
        if (instance.hasOwnProperty('subCmds')) {
            if (self.content.length > 0) {
                if (instance.subCmds.hasOwnProperty(self.content[0])) {
                    let subCmd = self.content.shift();
                    return exec(instance.subCmds[subCmd], exec_type);
                }
            }
        }
        if (self.options.hasOwnProperty('help')) {
            var help = new helpCmd();
            return help.printCmdDetail('', instance);
        } else if (exec_type == 'Exec') {
            if (typeof instance.Exec == 'function') {
                let result = instance.Exec(self.GetInputArgs(), terminal);
                terminal.showInputType();
                return result;
            } else {
                terminal.displayOutput('Command without handle function.');
            }
            return null;
        } else if (exec_type == 'config') {
            return instance.hasOwnProperty('config') ? instance.config : {};
        }
        return null;
    }

    // 判断命令是当前页面执行还是远端执行
    if (!from_remote && cmdInstance.hasOwnProperty('site') && location.href.indexOf(cmdInstance.site) == -1) {
        var config = exec(cmdInstance, 'config');
        config = $.extend(cmdInstance.config, config);
        api_send_message({
            type: 'exec-remote-command',
            site: cmdInstance.site,
            config: config,
            item: {
                'showType': 'background',
                'cmds': [self.input],
            }, 
            callback: function(result) {
                let cmd_datas = result && result.hasOwnProperty('data') ? result.data : [];
                if (cmd_datas.length > 0) {
                    for (let i in cmd_datas) {
                        if (typeof callback == 'function') callback(cmd_datas[i]);
                    }
                } else {
                    if (typeof callback == 'function') callback([]);
                }
            }
        });
    } else {
        var res = exec(cmdInstance, 'Exec');
        if (typeof callback == 'function') callback(res);
    }

}

Command.prototype.InputParser = function(input_str) {
    let string_arr = [];
    let str = "";
    let quote = "";

    for (let i=0; i<input_str.length; i++) {
        let chr = input_str.charAt(i);
        if (chr == " ") {
            // 如果不是引号中间出现的那么就进行分割
            if (!quote) {
                str && string_arr.push(str);
                str = "";
            } else {
                str += chr;
            }
        } else if (chr == '"' || chr == "'" || chr == "`") {
            // 如果是开头，则开始对字符串进行包裹
            if (!quote && str == "") {
                quote = chr;
            } else if (quote && quote == chr && input_str.charCodeAt(i-1) != 92) {  // 如果是结尾
                str && string_arr.push(str);
                quote = "";
                str = "";
            } else {
                str += chr;
            }
        } else {
            str += chr;
        }
    }
    str && string_arr.push(str);

    // console.log(string_arr);
    let args = Minimist(string_arr);
    for (let opt in args) {
        if (opt != '_') {
            this.options[opt] = args[opt];
        } else {
            if (args['_'].length > 0) {
                // confirm the prompt has be setted
                if (args['_'][0].startsWith('$')) {
                    this.name = args['_'][0].substring(1);
                    args['_'].splice(0, 1);
                } else if (!this.name) {
                    this.name = args['_'][0];
                    args['_'].splice(0, 1);
                }

                this.content = args['_'];
            }
        }
    }
}

Command.prototype.TransferSimpleOptions = function(cmdInstance, index) {
    index = typeof index == 'number' ? index : 0;
    var newOptions = {};
    if (this.content.length > index && cmdInstance.hasOwnProperty('subCmds') && cmdInstance.subCmds.hasOwnProperty(this.content[index])) {
        newOptions = this.TransferSimpleOptions(cmdInstance.subCmds[this.content[index]], ++index);
    } else {
        for (let inputOption in this.options) {
            var find = false;
            if (cmdInstance.hasOwnProperty('options')) {
                for (let configOption in cmdInstance.options) {
                    if (cmdInstance.options[configOption].hasOwnProperty('simple') && 
                        cmdInstance.options[configOption].simple == inputOption) {
                        newOptions[configOption] = this.options[inputOption];
                        find = true;
                        break;
                    }
                }
            }
            if (!find) {
                newOptions[inputOption] = this.options[inputOption];
            }
        }
        // if empty options and then use default option
        if (JSON.stringify(newOptions) === '{}' && cmdInstance.hasOwnProperty("defaultOption")) {
            newOptions[cmdInstance.defaultOption] = true;
        }
    }

    // parse option value
    var configOption = cmdInstance.hasOwnProperty('options') ? cmdInstance.options : {};
    for (var opt in newOptions) {
        if (configOption.hasOwnProperty(opt) && configOption[opt].hasOwnProperty('dataType')) {
            switch (configOption[opt].dataType) {
                case 'bool':
                    if (!newOptions[opt] || ["false", "0"].indexOf(newOptions[opt]) > -1) {
                        newOptions[opt] = false;
                    } else {
                        newOptions[opt] = true;
                    }
                break;
            }
        }
    }

    return newOptions;
}


var searchCmd = function()  {
    this.options = {
        google: {
            simple: "g",
            desc: "Use Google search engine.Useage: <code>search text -g</code> or <code>search text --google</code>",
            url: "https://www.google.com/search?q="
        },
        baidu: {
            simple: "d",
            desc: "Use Baidu search engine. Useage: <code>search text -d</code> or <code>search text --baidu</code>",
            url: "https://www.baidu.com/s?wd="
        },
        bing: {
            simple: "b",
            desc: "Use Bing search engine. Useage: <code>search text -b</code> or <code>search text --bing</code>",
            url: "https://cn.bing.com/search?q="   
        }
    };
    this.desc = "Useage: <code>search text</code> use the google as the default search engine.";
    this.defaultOption = "google";
    this.Exec = (command, terminal) => {
        var nums = 0;
        for (let option in command.options) {
            if (this.options.hasOwnProperty(option)) {
                nums++;
                setTimeout(() => {
                    console.log(command.content)
                    terminal.goToURL(encodeURI(this.options[option]['url']+command.content.join("")));
                }, nums*300);
            }
        }
    }
}

var translateCmd = function() {
    this.options = {
        google: {
            simple: "g",
            desc: "Use Google translate engine. Useage: <code>translate text -g</code> or <code>translate text --google</code>",
            url: "https://translate.google.cn/#view=home&op=translate&sl=auto&tl=auto&text="
        },
        baidu: {
            simple: "d",
            desc: "Use Baidu translate engine. Useage: <code>translate text -d</code> or <code>translate text --baidu</code>",
            url: "https://fanyi.baidu.com/#auto/auto/"
        },
        deepl: {
            simple: "l",
            desc: "Use Deepl translate engine. Useage: <code>translate text -l</code> or <code>translate text --deepl</code>",
            url: "http://deepl.com/translator#auto/auto/"
        }
    };
    this.desc = "Useage: <code>translate text</code> use the google as the default translate engine.";
    this.defaultOption = "google";
    this.Exec = (command, terminal) => {
        var nums = 0;
        for (let option in command.options) {
            if (this.options.hasOwnProperty(option)) {
                nums++;
                setTimeout(() => {
                    terminal.goToURL(encodeURI(this.options[option]['url']+command.content.join("")));
                }, nums*300);
            }
        }
        terminal.displayOutput("");
    }
}

var jsonCmd = function() {
    this.options = {
        "json-parser": {
            simple: "p",
            desc: "Use json-parser json engine. Useage: <code>json `{\"hello\":\"world\"}` -p</code> or <code>json `{\"hello\":\"world\"}` --json-parser</code>",
            url: "http://json.parser.online.fr/",
            selector: "#split textarea",
            triggers: [
                {
                    selector: "#split textarea",
                    trigger: "click"
                }
            ]
        },
        bejson: {
            simple: "b",
            desc: "Use bejson json engine. Useage: <code>json `{\"hello\":\"world\"}` -b</code> or <code>json `{\"hello\":\"world\"}` --bejson</code>",
            url: "https://www.bejson.com/jsonviewernew/",
            selector: "#edit",
            triggers: [
                {
                    selector: "#ext-gen45",
                    trigger: "click"
                }
            ]
        },
        jsoncn: {
            simple: "c",
            desc: "Use jsoncn json engine. Useage: <code>json `{\"hello\":\"world\"}` -c</code> or <code>json `{\"hello\":\"world\"}` --jsoncn</code>",
            url: "https://www.json.cn/",
            selector: "#json-src",
            triggers: [
                {
                    selector: "#json-src",
                    trigger: "change"
                }
            ]
        }
    };
    this.desc = "Useage: <code>json `{\"web\":\"terminal\"}`</code> use the json-parser as the default json engine.";
    this.defaultOption = "json-parser";
    this.Exec = (command, terminal) => {
        for (let option in command.options) {
            if (this.options.hasOwnProperty(option)) {
                let configOption = this.options[option];
                api_send_message({
                    type: "selector",
                    options: {
                        selector: configOption['selector'],
                        url: configOption['url'],
                        value: command.content.join("")
                    },
                    callback: function() {
                        if (configOption.hasOwnProperty('triggers')) {
                            for (let idx in configOption.triggers) {
                                api_send_message({
                                    type: "selector",
                                    options: {
                                        selector: configOption.triggers[idx]['selector'],
                                        url: configOption['url'],
                                        trigger: configOption.triggers[idx]['trigger']
                                    }
                                });
                            }
                        }
                    }
                });
            }
        }
        terminal.displayOutput("");
        
    }
}

var browserCmd = function() {
    this.desc = "Browser related commands";
    this.subCmds = {
        tabs: {
            desc: "View the tabs opened by the browser.",
            Exec: function(command, terminal) {
                var query = {};
                if (command.content.length > 0) {
                    query.title = '*'+command.content[0]+'*';
                }
                api_send_message({
                    type: "browser-tabs",
                    options: {query: query, type: 'query'},
                    callback: function(msg) {
                        let results = msg.data;
                        let showStr = "<style>div.tab{margin: 3px 0px;} div.tab a.active{color: green;} div.tab img{margin-top: -5px;vertical-align: middle;}</style>";
                        results.forEach(tab => {
                            showStr += "<div class='tab' data-type='tabs'>"+(terminal.is_extension_page ? "<img src='"+api_getIcon(tab.url)+"'>" : "")+" <a data-tab-id='"+tab.id+"' class='"+(tab.active ? 'active' : '')+"'>"+tab.title+"</a></div>";
                        });
                        terminal.displayOutput(showStr ? showStr : 'No result.');
                        terminal.options.selector.find('.cmd-output [data-type="tabs"] a[data-tab-id]').off('click').on('click', function() {
                            api_send_message({
                                type: "browser-tabs",
                                options: {tabId: $(this).data('tab-id'), type: 'update', updateProperties: {active: true}}
                            })
                        })
                    }
                });
            }
        },
        bookmark: {
            desc: "Browser bookmark <code>browser bookmark</code> or <code>browser bookmark 'query'</code>",
            Exec: function(command, terminal) {
                if (command.content.length > 0) {
                    api_send_message({
                        type: "browser-bookmarks",
                        options: {query: command.content[0], type: 'query'},
                        callback: function(msg) {
                            let results = msg.data;
                            let showStr = "<span class='green_highlight'>Search result:</span>";
                            results.forEach(element => {
                                showStr += "<div><a target='_blank' href='"+element.url+"'>"+element.title+"</a></div>";
                            });
                            terminal.displayOutput(showStr ? showStr : 'No result.')
                        }
                    });
                } else {
                    api_send_message({
                        type: "browser-bookmarks",
                        options: {numberOfItems: 15, type: 'getRecent'},
                        callback: function(msg) {
                            let results = msg.data;
                            let showStr = "<span class='green_highlight'>Recent 15: </span>";
                            results.forEach(element => {
                                showStr += "<div><a target='_blank' href='"+element.url+"'>"+element.title+"</a></div>";
                            });
                            terminal.displayOutput(showStr ? showStr : 'No result.')
                        }
                    });
                }
            }
        },
        history: {
            desc: "Browser history <code>browser history</code> or <code>browser history 'query'</code>",
            Exec: function(command, terminal) {
                api_send_message({
                    type: "browser-history",
                    options: {text: command.content.length > 0 ? command.content[0] : '', maxResults: 20},
                    callback: function(msg) {
                        console.log("callback msg: ", msg)
                        let results = msg.data;
                        let showStr = "<span class='green_highlight'>Search result in the past 24 hours:</span>";
                        results.forEach(element => {
                            showStr += "<div><a target='_blank' href='"+element.url+"'>"+element.title+"</a></div>";
                        });
                        terminal.displayOutput(showStr ? showStr : 'No result.')
                    }
                });
            }
        },
        notice: {
            desc: "Browser notice <code>browser notice -t basic -i https://developer.chrome.com/webstore/images/reader.png -T `It's test title` -m `main message` -M `content message`</code>",
            options: {
                type: {
                    simple: "t",
                    desc: "Which type of notification to display. type enum (basic, image, list, progress)",
                    options: ["basic", "image", "list", "progress"],
                    required: true
                },
                iconUrl: {
                    simple: "i",
                    desc: "A URL to the sender's avatar, app icon, or a thumbnail for image notifications.\
                            URLs can be a data URL, a blob URL",
                    required: true
                },
                title: {
                    simple: "T",
                    desc: "Title of the notification (e.g. sender name for email).",
                    required: true
                },
                message: {
                    simple: "m",
                    desc: "Main notification content.",
                    required: true
                },
                contextMessage: {
                    simple: "M",
                    desc: "Alternate notification content with a lower-weight font.",
                }
            },
            Exec: function(command, terminal) {
                // todo valid required params
                api_send_message({type: "browser-notifications", options: command.options});
                terminal.displayOutput("")
            }
        }
    }
}
var googleCmd = function() {
    var self = this;
    this.site = 'google.com';
    this.subCmds = {
        translate: {
            config: {
                match_url: 'https://docs.qq.com/desktop*',
                exec_all_match_url: false,
                active_url: false,
                auto_open: true
            },
            Exec: function(command) {
                
            }
        }
    };

    this.options = {

    };

    this.Exec = function(command) {

    };

}
var qqdocCmd = function() {
    var self = this;
    this.desc = 'qqdoc commands';
    this.site = 'https://docs.qq.com';
    this.config = {
        match_url: 'https://docs.qq.com/desktop*',
        exec_all_match_url: false,
        login_url: 'https://docs.qq.com/desktop/',
        active_url: false,
        auto_open: true
    };
    
    this.subCmds = {
        cd: {
            desc: '文件夹切换',
            Exec: function(command) {
                if (command.content.length > 0) {
                    var command_list = [];
                    folders = command.content[0].split('/');
                    folders.forEach((folder) => {
                        command_list.push("qqdoc open " + folder);
                    });
                    return {
                        type: 'command-list',
                        data: command_list
                    }
                } else {
                    return {type: 'html-text', data: 'Please enter sub-folders, use / split between folders.'};
                }
            }
        },
        open: {
            config: {
                active_url: true,
            },
            desc: '打开文件或文件夹',
            Exec: function(command) {
                if (command.content.length > 0) {
                    var sub = command.content[0].replace('#', '');
                    if (isNumber(sub)) {
                        $('#list-content').find('.list-item:eq('+(parseInt(sub)-1)+') a.item-name-title:first')[0].click();
                    } else if (sub.startsWith('..')) {
                        var len = sub.split('..').length;
                        var current = $('.doclist-content .breadcrumbs-item:last');
                        while(len > 1) {
                            current = current.prev();
                            len--;
                        }
                        current.find('a')[0].click();
                    } else {
                        $('#list-content').find('.list-item a.item-name-title[title="'+command.content[0]+'"]')[0].click();
                    }
                }
            }
        },
        pwd: {
            Exec: function(command) {
                var str = '/';
                $('.doclist-content .breadcrumbs-item').each(function() {
                    str += $(this).find('a').text()+'/';
                });
                return {type: 'html-text', data: str};
            }
        },
        ls: {
            Exec: function(command) {
                if (command.content.length > 0) {
                    var command_data = self.subCmds.cd.Exec(command);
                    command_data.data.push('qqdoc ls');
                    return command_data;
                } else {
                    var list = [];
                    var listContent = $('#list-content').find('.list-item');
                    var remote_tab = '';
                    // 跨页面事件监听
                    if (listContent.length > 0) {
                        $('#list-content').find('.list-item').each(function(i) {
                            list.push({
                                title: '#'+(i+1)+' '+$(this).find('.item-name-title').text()+($(this).attr('data-listinfotype') == 2 ? '/' : ''),
                            });
                        });
                    } else {
                        list.push({
                            title: 'please login <a target="_blank" href="'+self.config.login_url+'">docs.qq.com</a> and then try again.',
                        });
                        window.close();
                    }
                    
                    return {type: 'data-list', data: list};
                }
            }
        },
        create: {
            desc: '创建文件',
            subCmds: {
                doc: {
                    desc: '创建在线文档',
                    Exec: function() {
                        $('.new-doc-item[aria-label="在线文档"]')[0].click();
                    }
                },
                xls: {
                    desc: '创建在线表格',
                    Exec: function() {
                        $('.new-doc-item[aria-label="在线表格"]')[0].click();
                    }
                },
                ppt: {
                    desc: '创建在线幻灯片',
                    Exec: function() {
                        $('.new-doc-item[aria-label="在线幻灯片"]')[0].click();
                    }
                },
                coll: {
                    desc: '创建在线收集表',
                    Exec: function() {
                        $('.new-doc-item[aria-label="在线收集表"]')[0].click();
                    }
                },
            }
        }
    };
    this.TabComplete = function(command) {
        if (command.content.length > 0) {
            var subCmd = command.content.shift();
            switch (subCmd) {
                case 'ls':
                case 'cd':
                    return self.subCmds.ls.Exec(command);
                case 'pwd':
                    return self.subCmds.pwd.Exec(command);
                case 'open':
                    return self.subCmds.ls.Exec(command);
                default:
                    break;
            }
        }
    };
    this.Exec = function(command) {
        return self.subCmds.ls.Exec(command);;
    }
}
var cmdCmd = function() {
    this.subCmds = {
        add: {
            desc: "<code>cmd add [command]</code> add a command. <code>cmd add github</code> the github command will be adding.",
            Exec: function(command, terminal) {
                if (command.content.length > 0) {
                    let newCmd = command.content[0].trim();
                    // get the 
                    api_send_message({type: "cmdhub", method: "add", newCmd: newCmd, callback: function(res) {
                        if (res.meta.code == 200) {
                            $.extend(terminal.customcmds, res.meta.data);
                            for (let cmd in terminal.customcmds) {
                                terminal.all_commands[cmd] = terminal.customcmds[cmd]['index_func'];
                            }
                            terminal.displayOutput(newCmd+" added.");
                        } else {
                            terminal.displayErrorOutput(res.meta.msg);
                        }
                    }});
                } else {
                    terminal.displayErrorOutput("Input the command names what you want to add.");
                }
            }
        },
        update: {
            desc: "<code>cmd update [command]</code> update a command. <code>cmd update github</code> to update the github commands latest version.",
            Exec: function(command, terminal) {
                if (command.content.length > 0) {
                    let newCmd = command.content[0].trim();
                    api_send_message({type: "cmdhub", method: "update", newCmd: newCmd, callback: function(res) {
                        if (res.meta.code == 200) {
                            $.extend(terminal.customcmds, res.meta.data);
                            for (let cmd in self.customcmds) {
                                terminal.all_commands[cmd] = terminal.customcmds[cmd]['index_func'];
                            }
                            terminal.displayOutput(newCmd+" updated.");
                        } else {
                            terminal.displayErrorOutput(res.meta.msg);
                        }
                    }});
                } else {
                    terminal.displayErrorOutput("Input the command names what you want to update.");
                }
            }
        },
        delete: {
            desc: "<code>cmd delete [command]</code> delete a command. <code>cmd delete github</code> to delete github command.",
            Exec: function(command, terminal) {
                if (command.content.length > 0) {
                    let newCmd = command.content[0].trim();
                    api_send_message({type: "cmdhub", method: "delete", newCmd: newCmd, callback: function(res) {
                        if (res.meta.code == 200) {
                            delete terminal.customcmds[newCmd];
                            delete terminal.all_commands[newCmd];
                            terminal.displayOutput(newCmd+" deleted.");
                        } else {
                            terminal.displayErrorOutput(res.meta.msg);
                        }
                    }});
                } else {
                    terminal.displayErrorOutput("Input the command names what you want to delete.");
                }
            }
        },
        custom: {
            desc: 'Custom command',
            Exec: function(command, terminal) {
                if (command.content.length > 1) {
                    var newCmd = command.content[0];
                    // 命令名成不允许和系统命令相同
                    if (terminal.syscmds.hasOwnProperty(newCmd)) {
                        terminal.displayErrorOutput("Command "+newCmd+" is system command.");
                    } else {
                        api_send_message({type: "cmdhub", method: "custom", newCmd: newCmd, cmdContent: command.content[1], callback: function(res) {
                            if (res.meta.code == 200) {
                                $.extend(terminal.customcmds, res.meta.data);
                                for (let cmd in terminal.customcmds) {
                                    terminal.all_commands[cmd] = terminal.customcmds[cmd]['index_func'];
                                }
                                terminal.displayOutput(newCmd+" added.");
                            } else {
                                terminal.displayErrorOutput(res.meta.msg);
                            }
                        }});
                    }
                }
            }
        }
    }
    this.desc = "This is Terminal's command manager. like nodejs npm.";
}
var cronCmd = function() {
    this.options = {
        list: {
            simple: "l",
            desc: "Useage: <code>cron -l</code> show all the crontab tasks"
        },
        add: {
            simple: "a",
            desc: "Useage: <code>cron `00 * * * * *` `js console.log(123);` -a</code> Add a new contab task"
        },
        delete: {
            simple: "D",
            desc: "Useage: <code>cron 4f0wr4ynbs80 -D</code> delete the specified contab task"
        },
        showType: {
            simple: "s",
            desc: "Useage: <code>cron 4f0wr4ynbs80 -s background</code> Update the show type when cron job excute. the options is background or frontend."
        },
        openType: {
            simple: "o",
            desc: "Useage: <code>cron 4f0wr4ynbs80 -o auto-open</code> Update the show type when cron job excute. the option is auto-open, open-only, finished-close."
        },
        enabled: {
            simple: "e",
            desc: "Useage: <code>cron 4f0wr4ynbs80 -e 0</code> Update the enabled status. the options is 0 or 1"
        },
        url: {
            simple: "u",
            desc: "Useage: <code>cron 4f0wr4ynbs80 -u http://www.google.com</code> Update the host page url address."
        },
        rule: {
            simple: "r",
            desc: "Useage: <code>cron 4f0wr4ynbs80 -r `01 * * * * *`</code> Update the rule of cron."
        },
        command: {
            simple: "c",
            desc: "Useage: <code>cron 4f0wr4ynbs80 -c `time -t`</code> Update the executor command."
        },
    }
    this.desc = "Useage: <code>cron `*/3 * * * * *` \"js `console.log('hello WebTerminal!')`\" -a</code>";
    this.defaultOption = "list";
    this.Exec = function(command, cmdwin) {
        if (command.options.hasOwnProperty("list")) {
            api_send_message({
                type: "cron-job",
                options: {
                    type: "list"
                },
                callback: function(msg) {
                    let cronJobs = msg.data;
                    if (JSON.stringify(cronJobs) == '{}') {
                        cmdwin.displayOutput("You haven't added cron tasks.")
                    } else {
                        let showStr = '<table width="100%"><tr><th>id</th><th>rule</th><th>cmds</th><th>enabled</th><th>showType</th><th>openType</th></tr>';
                        for (let id in cronJobs) {
                            showStr += '<tr title="'+cronJobs[id]['url']+'"><td>'+id+'</td>';
                            showStr += '<td>'+cronJobs[id]['rule']+'</td>';
                            showStr += '<td>'+cronJobs[id]['cmds'].join('<br/>')+'</td>';
                            showStr += '<td>'+cronJobs[id]['enabled']+'</td>';
                            showStr += '<td>'+cronJobs[id]['showType']+'</td>';
                            showStr += '<td>'+cronJobs[id]['openType']+'</td>';
                            // showStr += '<td>'+cronJobs[id]['times']+'</td>';
                            showStr += '</tr>';
                        }
                        showStr += '</table>'
                        cmdwin.displayOutput(showStr);
                    }
                }
            });
        } else if (command.options.hasOwnProperty("add")) {
            var cronRule = command.content[0];
            command.content.splice(0, 1)
            var options = {
                type: "add",
                rule: cronRule,
                cmds: command.content
            }
            if (command.options.hasOwnProperty('showType') && ["background", "frontend"].indexOf(command.options.showType) > -1) {
                options['showType'] = command.options.showType
            }
            if (command.options.hasOwnProperty('openType') && ["auto-open", "only-open", "finished-close"].indexOf(command.options.openType) > -1) {
                options['openType'] = command.options.openType
            }
            if (command.options.hasOwnProperty('url')) {
                options['url'] = command.options.url
            }
            // console.log("add cron:", cronRule, command.content)
            api_send_message({
                type: "cron-job",
                options: options,
                callback: function(msg) {
                    cmdwin.handleInput('cron -l');
                }
            });
        } else if (command.options.hasOwnProperty("delete")) {
            let id = command.options.delete;
            if (typeof id == "boolean") id = command.content[0];
            api_send_message({
                type: "cron-job",
                options: {
                    type: "delete",
                    id: id
                },
                callback: function(msg) {
                    cmdwin.handleInput('cron -l');
                }
            });
        } else {
            var options = {
                type: "update"
            }
            if (command.content.length > 0) {
                options['id'] = command.content[0];
            }
            if (command.options.hasOwnProperty('enabled')) {
                options['enabled'] = command.options.enabled ? true : false;
            }
            if (command.options.hasOwnProperty('showType') && ["background", "frontend"].indexOf(command.options.showType) > -1) {
                options['showType'] = command.options.showType;
            }
            if (command.options.hasOwnProperty('openType') && ["auto-open", "only-open", "finished-close"].indexOf(command.options.openType) > -1) {
                options['openType'] = command.options.openType;
            }
            if (command.options.hasOwnProperty('url') && isURL(command.options.url)) {
                options['url'] = command.options.url;
            }
            if (command.options.hasOwnProperty('rule')) {
                options['rule'] = command.options.rule;
            }
            if (command.options.hasOwnProperty('command')) {
                options['cmds'] = typeof command.options.command == 'string' ? [command.options.command] : command.options.command;
            }

            api_send_message({
                type: "cron-job",
                options: options,
                callback: function(msg) {
                    cmdwin.handleInput('cron -l');
                }
            });
        }
    }
}
var jsCmd = function() {
    this.options = {
        current: {
            simple: ["c"],
            desc: "Useage: <code>js `alert('hello web terminal.')` -c</code> Or <code>js `alert('hello web terminal.')`</code> to exec js code at the current page."
        },
        url: {
            simple: "u",
            desc: "Useage: <code>js `alert('hello web terminal.')` -u https://www.google.com</code> to exec js code at the specified url page."
        },
        active_tab: {
            simple: "a",
            dataType: 'bool',
            desc: "Useage: <code>js `alert('hello web terminal.')` -u https://www.google.com -a</code> to exec js code at the specified url page and active this page tab."
        },
        file: {
            simple: "f",
            desc: "Useage: <code>js https://buttons.github.io/buttons.js -f</code> to exec js file at the specified page."
        }
    }
    this.desc = "This command is very powerful. you can use javascript code to finish your task, and jquery also be supported. eg: <code>js `$('#name').val('ok')` `var a = 1;` `alert(a);`</code>"
    this.Exec = (command, cmdwin) => {
        let execjs = function(content) {
            api_send_message({
                type: "js",
                options: command.options,
                content: content,
                feed_data: cmdwin.feed_data,
                callback: function(msg) {
                    cmdwin.displayOutput(msg.response);
                }
            });
        }
        if (command.options.hasOwnProperty('file')) {
            let url = isURL(command.options.file) ? command.options.file : command.content[0];
            if (isURL(url)) {
                let ajaxConfig = {
                    url: url,
                    type: 'GET',
                    async: true,
                    dataType: 'text'
                }
                api_send_message({
                    type: 'ajax-request', 
                    config: ajaxConfig,
                    callback: function(res) {
                        execjs([res.data.xhr.responseText]);
                    }
                });
            }
        } else {
            execjs(command.content);
        }
        
    }
}
var lsCmd = function() {
    this.desc = 'Show the current commands or options.';
    this.Exec = function(command, cmdwin) {
        let help = new helpCmd();
        let showStr = "";
        if (command.content.length > 0) {
            if (cmdwin.all_commands.hasOwnProperty(command.content[0])) {
                commandObject = new cmdwin.all_commands[command.content[0]]();
                // has sub command?
                showStr += help.printCmdDetail('', commandObject);
            }
        } else {
            showStr += help.printCmds(cmdwin.all_commands);
        }
        cmdwin.displayOutput(showStr)
    }
}

var cdCmd = function() {
    this.desc = 'Change to the command space.';
    this.Exec = function(command, cmdwin) {
        if (command.content.length > 0) {
            if (!command.content[0].trim()) {
                cmdwin.setPrompt("$ ");
                cmdwin.displayOutput("")
            } else if (cmdwin.all_commands.hasOwnProperty(command.content[0])) {
                cmdwin.setPrompt("$"+command.content[0]+" ");
                cmdwin.displayOutput("")
            } else {
                cmdwin.displayErrorOutput("invalid command "+command.content[0]);
            }
        } else {
            cmdwin.setPrompt("$ ");
            cmdwin.displayOutput("")
        }
    }
}

var clearCmd = function() {
    this.options = {
        screen: {
            simple: "s",
            desc: "clear screen. <code>clear -s</code>",
        },
        history: {
            simple: "h",
            desc: "clear history. <code>clear -h</code>",
        }
    }
    this.desc = 'clear datas. useage <code>clear</code>';
    this.defaultOption = 'screen';
    this.Exec = function(command, cmdwin) {
        for (let option in command.options) {
            switch (option) {
            case "screen":
                // clear screen
                cmdwin.clearScreen();
            break;
            case "history":
                // clear history
                cmdwin.cmd_stack.empty();
                cmdwin.cmd_stack.reset();
                cmdwin.displayOutput('Command history cleared. ');
            break;
            default:
                cmdwin.displayOutput('Place use the right option.');
            }
        }
    }
}

var themeCmd = function() {
    this.options = {
        dark: {
            simple: "d",
            desc: "typical mode",
        },
        white: {
            simple: "w",
            desc: "舒适模式",
        }
    };

    this.desc = "Theme controller";

    this.Exec = function(command, cmdwin) {
        cmdwin.invert();
        cmdwin.displayOutput('Shazam.');
    }
}

var talkCmd = function() {
    this.options = {
        enabled: {
            simple: "e",
            desc: "enabled talk"
        },
        disabled: {
            simple: "d",
            desc: "disabled talk"
        },
        stop: {
            simple: "s",
            desc: "stop talk"
        }
    };
    this.defaultOption = "enabled";
    this.desc = "voice controller";

    this.Exec = function(command, cmdwin) {
        if (!cmdwin.speech_synth_support) {
            cmdwin.displayOutput('You browser doesn\'t support speech synthesis.');
            return false;
        }
        for (let option in command.options) {
            if (["enabled", "disabled"].indexOf(option) > -1) {
                if (option == 'enabled') cmdwin.options.talk = true;
                else if (option == 'disabled') cmdwin.options.talk = false;
                cmdwin.displayOutput((cmdwin.options.talk ? 'Talk mode enabled.' : 'Talk mode disabled.'));
            } else if (option == "stop") {
                if (cmdwin.options.talk) {
                    window.speechSynthesis.cancel();
                    cmdwin.options.talk = false;
                    cmdwin.displayOutput('Speech stopped. Talk mode is still enabled. Type TALK to disable talk mode.');
                    cmdwin.options.talk = true;
                } else {
                    cmdwin.displayOutput('Ok.');
                }
            }
        }
    }

}

var curlCmd = function() {
    this.options = {
        user: {
            simple: "u",
            desc: "Usage: <code>curl http://api.xxx.com -u username:password</code> Server user and password"
        },
        header: {
            simple: "H",
            desc: "Usage: <code>curl http://api.xxx.com -H header1:v1 -H header2:v2</code> Pass custom header(s) to server"
        },
        get: {
            simple: "G",
            desc: "Usage: <code>curl http://api.xxx.com -G</code> Put the post data in the URL and use GET"
        },
        timeout: {
            desc: "Usage: <code>curl http://api.xxx.com --timeout</code> Set the seconds request timeout."
        },
        data: {
            simple: "d",
            desc: 'Usage: <code>curl http://api.xxx.com -d {"k1":v1, "k2":"v2"}</code> Or <code>curl http://api.xxx.com -d k1=v1&k2=v2</code> HTTP POST data'
        },
        include: {
            simple: "i",
            desc: "Usage: <code>curl http://api.xxx.com -i</code> Include protocol response headers in the output"
        }
    };
    this.desc = "Usage: <code>curl http://api.xxx.com -u username:password -d `{\"field\": \"value\"}` -i </code> Or <code>curl http://api.xxx.com -u username:password -d k1=v1&k2=v2&k3=v3 -i</code>";
    this.defaultOption = "get";
    this.Exec = function(command, cmdwin) {
        if (command.content.length < 1) {
            cmdwin.displayOutput("no url input.");
        } else {
            let ajaxConfig = {
                url: command.content[0],
                type: 'GET',
                async: true,
                dataType: 'text'
            }
            // data
            if (command.options.hasOwnProperty('data')) {
                ajaxConfig['type'] = 'POST';

                if (typeof command.options.data == 'object') {
                    let data = {};
                    for (let i in command.options.data) {
                        let element = command.options.data[i];
                        let keyval = element.indexOf(':') > -1 ? element.split(':') : element.split('=');
                        console.log(keyval)
                        if (keyval.length > 1) {
                            data[$.trim(keyval[0])] = $.trim(keyval[1]);
                        } else {
                            data[i] = element;
                        }
                    }
                    ajaxConfig['data'] = data;
                } else {
                    ajaxConfig['data'] = command.options.data;
                }
            }
            // header
            if (command.options.hasOwnProperty('header')) {
                let header = {};
                if (typeof command.options.header == 'string') {
                    command.options.header = [command.options.header];
                }
                command.options.header.forEach(element => {
                    let keyval = element.indexOf(':') > -1 ? element.split(':') : element.split('=');
                    header[$.trim(keyval[0])] = keyval.length > 1 ? $.trim(keyval[1]) : true;
                    // console.log(keyval, header)
                });
                ajaxConfig['header'] = header;
            }
            // user
            if (command.options.hasOwnProperty('user')) {
                let keyval = command.options.user.split(':')
                ajaxConfig['username'] = keyval.length > 0 ? keyval[0] : '';
                ajaxConfig['password'] = keyval.length > 1 ? keyval[1] : '';
            }
            // get
            if (command.options.hasOwnProperty('get')) {
                ajaxConfig['type'] = 'GET';
            }
            // timeout
            if (command.options.hasOwnProperty('timeout')) {
                ajaxConfig['timeout'] = command.options['timeout'];
            }
            // ajax-request
            api_send_message({
                type: 'ajax-request', 
                config: ajaxConfig,
                callback: function(res) {
                    if (command.options.hasOwnProperty('include')) {
                        window.TerminalWin.displayOutput('============================ Request ========================');
                        for (let option in ajaxConfig) {
                            if (typeof ajaxConfig[option] != 'string') {
                                ajaxConfig[option] = JSON.stringify(ajaxConfig[option]);
                            }
                            window.TerminalWin.displayOutput(option+': '+ajaxConfig[option], true);
                        }
                        window.TerminalWin.displayOutput('============================ Response ========================');
                        window.TerminalWin.displayOutput('Status: '+res.data.xhr.status+' '+res.data.xhr.statusText);
                        // window.TerminalWin.displayOutput('TextStatus: '+res.data.xhr.status+' '+res.data.xhr.statusText, true);
                    }

                    window.TerminalWin.displayOutput(res.data.xhr.responseText, true)
                }
            });
        }
    }
}

var selectorCmd = function() {
    this.options = {
        selector: {
            simple: "s",
            desc: "the operate element"
        },
        current: {
            simple: "c",
            desc: "it will operate current tab"
        },
        url: {
            simple: "u",
            desc: "url"
        },
        value: {
            simple: "v",
            desc: "Sets or returns the value of the input type selected element"
        },
        text: {
            simple: "t",
            desc: "Sets or returns the text content of the selected element"
        },
        html: {
            simple: "h",
            desc: "Sets or returns the html content of the selected element"
        },
        css: {
            simple: "c",
            desc: "Sets or returns the css value of the selected element"
        },
        attr: {
            simple: "a",
            desc: "Sets or returns the attribute value of the selected element"
        },
        removeAttr: {
            simple: "A",
            desc: "Remove the specified attribute of the selected element"
        },
        prop: {
            simple: "p",
            desc: "Get the attribute value of the first element in the matched element set"
        },
        removeProp: {
            simple: "P",
            desc: "Remove the attribute value of the first element in the matched element set"
        },
        addClass: {
            simple: "d",
            desc: "Add the specified class name for each matched element"
        },
        removeClass: {
            simple: "D",
            desc: "Remove the specified class name for each matched element"
        },
        trigger: {
            simple: "o",
            desc: "the trigger of selector element",
            options: [
                "click", "blur", "focus", "keyup", "keydown", "keypress",
                "change", "dblclick", "error", "focusin", "focusout",
                "mousedown", "mouseup", "mouseover", "mouseout", "mousemove", "mouseleave", "mouseenter",
                "resize", "scroll", "select", "submit", "unload"
            ]
        }
    };
    this.defaultOption = "current";
    this.desc = "Usage: <code>selector #id -t</code>";

    this.Exec = function(command, cmdwin) {
        api_send_message({
            type: "selector",
            options: command.options,
            content: command.content,
            callback: function(msg) {
                cmdwin.displayOutput(msg.response);
            }
        });     
    }
}

var helpCmd = function() {
    var self = this;
    this.desc = "Show the command how to use. eg: help"
    this.printCmdDetail = function(cmd, commandConfig) {
        let showStr = '<div style="margin-left: 15px;">';
        // desc
        if (commandConfig.hasOwnProperty('desc'))
            showStr += "<div>"+ (cmd ? cmd + ": " : '') + commandConfig.desc +"</div>";
        if (commandConfig.hasOwnProperty('options')) {
            for (let option in commandConfig.options) {
                showStr += '<div style="margin-left: 15px;">'
                showStr += '<span>'+(commandConfig.options[option].hasOwnProperty('simple') ? ('-'+commandConfig.options[option]['simple'][0]) : '&nbsp;&nbsp;')+'</span>'
                showStr += '<span class="help-span">--'+option+'</span>'
                showStr += '<span class="help-span">'+(commandConfig.options[option].hasOwnProperty('desc') ? commandConfig.options[option]['desc'] : '')+'</span>'
                showStr += '</div>'
            }
        }
        if (commandConfig.hasOwnProperty('subCmds')) {
            for (let subcmd in commandConfig.subCmds) {
                showStr += self.printCmdDetail(subcmd, commandConfig.subCmds[subcmd]);
            }
        }
        
        return showStr+'</div>';
    }

    this.printCmds = function(all_commands) {
        let showStr = "";
        for (let cmd in all_commands) {
            showStr += '<span class="blue_highlight help-span">'+cmd+'</span>';
        }
        return showStr;
    }

    this.Exec = function(command, cmdwin) {
        let showStr = ''
        if (command.content.length > 0) {
            command.content.forEach(cmd => {
                if (cmdwin.all_commands.hasOwnProperty(cmd)) {
                    commandObject = new cmdwin.all_commands[cmd]();
                    showStr += this.printCmdDetail('', commandObject);
                } else {
                    showStr += cmdwin.getErrorOutput('the command "'+cmd+'" is invalid.')
                }
            });
        } else {
            showStr += this.printCmds(cmdwin.all_commands)
        }
        cmdwin.displayOutput(showStr);
    }
}

var timeCmd = function() {
    this.options = {
        timestamp: {
            simple: "t",
            desc: "Get timestamp. useage: <code>time `2020-07-04 14:00:00` -t</code>"
        },
        microtimestamp: {
            simple: "m",
            desc: "Get micro timestamp. useage: <code>time `2020-07-04 14:00:00` -m</code>"
        },
        date: {
            simple: "d",
            desc: "Get date. useage: <code>time `1593842041976` -d</code>"
        }
    };
    this.desc = "Useage: <code>time `2020-07-04 14:00:00` -t</code>"
    this.defaultOption = "date";
    this.Exec = function(command, cmdwin) {
        if (command.options.hasOwnProperty('timestamp')) {
            var timestamp = null;
            if (typeof command.options.timestamp != "boolean") {
                timestamp = new Date(command.options.timestamp).getTime();
            } else if (command.content.length > 0) {
                timestamp = new Date(command.content[0]).getTime();
            } else {
                timestamp = new Date().getTime()
            }
            cmdwin.displayOutput(parseInt(timestamp/1000)+'');
        }
        if (command.options.hasOwnProperty('microtimestamp')) {
            var microtimestamp = null;
            if (typeof command.options.microtimestamp != "boolean") {
                microtimestamp = new Date(command.options.microtimestamp).getTime();
            } else if (command.content.length > 0) {
                microtimestamp = new Date(command.content[0]).getTime();
            } else {
                microtimestamp = new Date().getTime()
            }
            cmdwin.displayOutput(microtimestamp+'');
        }
        if (command.options.hasOwnProperty('date')) {
            let Pad = function(num, n, right) {
                var len = num.toString().length;
                while(len < n) {
                    if (right) num = num + "0";
                    else num = "0" + num;
                    len++;
                }
                return num;
            }
            var date = new Date();
            if (typeof command.options.date != "boolean") {
                date = new Date(parseInt(Pad(command.options.date, 13, 1)));
            } else if (command.content.length > 0) {
                date = new Date(parseInt(Pad(command.content[0], 13, 1)));
            }

            var year = date.getFullYear();
            var month = Pad(date.getMonth()+1, 2);    //js从0开始取 
            var date1 = Pad(date.getDate(), 2); 
            var hour = Pad(date.getHours(), 2); 
            var minutes = Pad(date.getMinutes(), 2); 
            var second = Pad(date.getSeconds(), 2);
            cmdwin.displayOutput(year+'-'+month+'-'+date1+' '+hour+':'+minutes+':'+second);
        }
    }
}

var terminalCmd = function () {
    this.desc = 'Set window properties <code>terminal max</code>',
    this.subCmds = {
        max: {
            desc: 'Maximize window',
            Exec: function(command, terminal) {
                terminal.options.selector.css({"width": '100%', "height": '100%', "left": "0px", "top": "0px"});
            }
        },
        min: {
            desc: "Minimize window",
            Exec: function(command, terminal) {
                terminal.options.selector.css({"width": '60%', "height": '60%', "left": "20%", "top": "20%"});
            }
        },
        close: {
            desc: "Close and clean the window",
            Exec: function(commands, terminal) {
                terminal.clearScreen();
                toggleCmdWin('hide');
            }
        },
        hide: {
            desc: "Hide the window",
            Exec: function() {
                toggleCmdWin('hide');
            }
        },
        position: {
            desc: "Set the position of the window. <code>terminal position -l 0 -t 0</code> The window is near the upper left corner.",
            options: {
                left: {
                    simple: 'l',
                    desc: 'Distance to the left',
                },
                top: {
                    simple: 't',
                    desc: 'Distance to the top',
                },
                right: {
                    simple: 'r',
                    desc: 'Distance to the right',
                },
                bottom: {
                    simple: 'b',
                    desc: 'Distance to the bottom',
                },
                width: {
                    simple: 'w',
                    desc: 'The width of the window',
                },
                height: {
                    simple: 'h',
                    desc: 'The height of the window',
                },
            },
            Exec: function(commands, terminal) {
                if (commands.options.hasOwnProperty('left')) {
                    terminal.options.selector.css('left', commands.options['left']);
                }
                if (commands.options.hasOwnProperty('top')) {
                    terminal.options.selector.css('top', commands.options['top']);
                }
                if (commands.options.hasOwnProperty('bottom')) {
                    terminal.options.selector.css('bottom', commands.options['bottom']);
                }
                if (commands.options.hasOwnProperty('right')) {
                    terminal.options.selector.css('left', $(window).width() - terminal.options.selector.width() - commands.options['right']);
                }
                if (commands.options.hasOwnProperty('width')) {
                    terminal.options.selector.css('width', commands.options['width']);
                }
                if (commands.options.hasOwnProperty('height')) {
                    terminal.options.selector.css('height', commands.options['height']);
                }
            }
        },
    }
}
var syscmds = {
    "help": helpCmd,
    "ls": lsCmd,
    "cd": cdCmd, 
    "cmd": cmdCmd,
    "selector": selectorCmd,
    "js": jsCmd,
    "cron": cronCmd,
    "time": timeCmd,
    // "refresh": refreshCmd,
    // "pwd": pwdCmd,
    "clear": clearCmd,
    "terminal": terminalCmd,
    // "invert": invertCmd,
    // "talk": talkCmd,a
// };

// var customcmds = {
    "curl": curlCmd,
    "search": searchCmd, 
    "translate": translateCmd,
    "json": jsonCmd,
    "browser": browserCmd,
    "qqdoc": qqdocCmd,
    // "bookmark": bookmarkCmd,
    // "test": testCmd,
}
// const { trim } = require("jquery");
if (!String.prototype.startsWith) {
  String.prototype.startsWith = function(searchString, position) {
    position = position || 0;
    return this.indexOf(searchString, position) === position;
  };
}

//jQuery实现textarea高度根据内容自适应
$.fn.extend({
  txtaAutoHeight: function () {
      return this.each(function () {
          var $this = $(this);
          if (!$this.attr('initAttrH')) {
              $this.attr('initAttrH', $this.outerHeight());
          }
          setAutoHeight(this).on('input', function () {
              setAutoHeight(this);
          });
          setAutoHeight(this).on('focus', function () {
            setAutoHeight(this);
        });
      });
      function setAutoHeight(elem) {
          var $obj = $(elem);
          return $obj.css({ height: $obj.attr('initAttrH'), 'overflow-y': 'hidden' }).height(elem.scrollHeight);
      }
  }
})
  
  /**
   * Stack for holding previous commands for retrieval with the up arrow. 
   * Stores data in localStorage. Won't push consecutive duplicates.
   *
   * @author   Jake Gully, chimpytk@gmail.com
   * @license  MIT License
   */
  
  /**
   * Constructor
   * @param {string}  id       Unique id for this stack
   * @param {integer} max_size Number of commands to store
   */
  function CmdStack(id, max_size) {
    "use strict";
  
    var instance_id = id,
        cur = 0,
        arr = []; // This is a fairly meaningless name but
                  // makes it sound like this function was
                  // written by a pirate.  I'm keeping it.
  
    if (typeof id !== 'string') {
      throw 'Stack error: id should be a string.';
    }
  
    if (typeof max_size !== 'number') {
      throw 'Stack error: max_size should be a number.';
    }
    
    function getCmdStackKey() {
      return "cmd_stack_"+instance_id;
    }
  
    /**
     * Store the array in localstorage
     */
    function setArray(stackList) {
      // localStorage['cmd_stack_' + instance_id] = JSON.stringify(arr);
      let data = {};
      data[getCmdStackKey()] = stackList;
      api_storage_sync_set(data);
    }
  
    /**
     * Load array from localstorage
     */
    function getArray(callback) {
      api_storage_sync_get(getCmdStackKey(), function(result) {
          if (result.hasOwnProperty(getCmdStackKey())) {
            callback && callback(result[getCmdStackKey()]);
          } else {
            callback && callback([]);
          }
      });
    }
  
    /**
     * Push a command to the array
     * @param  {string} cmd Command to append to stack
     */
    function push(cmd) {
      getArray(items => {
        arr = items;
        // don't push if same as last command
        if (cmd === arr[arr.length - 1]) {
          return false;
        }
        arr.push(cmd);

        // crop off excess
        while (arr.length > max_size) {
          arr.shift();
        }

        cur = arr.length;
        setArray(arr);
      });
    }
  
    /**
     * Get previous command from stack (up key)
     * @return {string} Retrieved command string
     */
    function prev() {
      cur -= 1;
  
      if (cur < 0) {
        cur = 0;
      }
  
      return arr[cur];
    }
  
    /**
     * Get next command from stack (down key)
     * @return {string} Retrieved command string
     */
    function next() {
      cur = cur + 1;
  
      // Return a blank string as last item
      if (cur === arr.length) {
        return "";
      }
  
      // Limit
      if (cur > (arr.length - 1)) {
        cur = (arr.length - 1);
      }
  
      return arr[cur];
    }
  
    /**
     * Move cursor to last element
     */
    function reset() {
      getArray(items => {
        arr = items;
        cur = arr.length;
      });
    }
    
    /**
     * Empty array and remove from localstorage
     */
    function empty() {
      arr = undefined;
      localStorage.clear();
      api_storage_sync_remove(getCmdStackKey());
      reset();
    }
  
    /**
     * Get current cursor location
     * @return {integer} Current cursor index
     */
    function getCur() {
      return cur;
    }
  
    /**
     * Get entire stack array
     * @return {array} The stack array
     */
    function getArr() {
      return arr;
    }
  
    /**
     * Get size of the stack
     * @return {Integer} Size of stack
     */
    function getSize(){
      return arr.length;
    }
  
    return {
      push: push,
      prev: prev,
      next: next,
      reset: reset,
      empty: empty,
      getCur: getCur,
      getArr: getArr,
      getSize: getSize
    };
  }
  
  function isURL(str) {
    var pattern = new RegExp('^(https?:\\/\\/)?'+ // protocol
    '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|'+ // domain name
    '((\\d{1,3}\\.){3}\\d{1,3}))'+ // OR ip (v4) address
    '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*'+ // port and path
    '(\\?[;&a-z\\d%_.~+=-]*)?'+ // query string
    '(\\#[-a-z\\d_]*)?$','i'); // fragment locator
    return pattern.test(str);
  }

  function htmlEncode(str) {
    var s = "";
    if (str.length === 0) {
      return "";
    }
    s = str.replace(/&/g, "&amp;");
    s = s.replace(/</g, "&lt;");
    s = s.replace(/>/g, "&gt;");
    s = s.replace(/ /g, "&nbsp;");
    s = s.replace(/\'/g, "&#39;");//IE下不支持实体名称
    s = s.replace(/\"/g, "&quot;");
    return s;
  }

  /**
   * HTML5 Command Line Terminal
   */
  (function (root, factory) {
    if ( typeof define === 'function' && define.amd ) {
      define(factory);
    } else if ( typeof exports === 'object' ) {
      module.exports = factory();
    } else {
      root.TerminalWin = factory();
    }
  }(this, function () {
    "use strict";
    var TerminalWin = function (user_config) {
      this.keys_array    = [9, 13, 38, 40, 27],
      this.timeout       = 30;
      this.style         = 'dark',
      this.output_init   = '<code><div>'+api_locales('terminal_desc', api_locales('version'))+'</div></code>',
      this.popup         = true,
      this.prompt_str    = '$ ',
      this.autofill      = '',
      this.tab_nums      = 0,
      this.speech_synth_support = ('speechSynthesis' in window && typeof SpeechSynthesisUtterance !== 'undefined'),
      this.options       = {
        busy_text:           'Communicating...',
        external_processor:  function() {},
        filedrop_enabled:    false,
        // file_upload_url:     'ajax/uploadfile.php',
        history_id:          'cmd_history',
        selector:            '#cmd',
        talk:                false,
        typewriter_time:     32
      },
      this.voices = false;
      this.is_extension_page = location.href.startsWith('chrome-extension://') ? true : false;
      this.customcmds = {};
      this.syscmds = Object.keys(syscmds);
      this.all_commands = syscmds;
  
      $.extend(this.options, user_config);
      
      var self = this;
      api_send_message({
        type: 'cmdhub',
        method: 'get_cmdhub',
        callback: function(res) {
          if (typeof res == 'object') {
            $.extend(self.customcmds, res.meta.data);
            for (let cmd in self.customcmds) {
              self.all_commands[cmd] = self.customcmds[cmd]['index_func'];
            }
          }
        }
      });
      
      if (!$(this.options.selector).length) {
        throw 'Cmd err: Invalid selector.';
      }
  
      this.cmd_stack = new CmdStack(this.options.history_id, 30);
  
      this.cmd_stack.reset();
      this.setupDOM();
      this.input.focus();
    }
  
    // ====== Layout / IO / Alter Interface =========
  
    /**
     * Create DOM elements, add click & key handlers
     */
    TerminalWin.prototype.setupDOM = function() {
      this.wrapper = $(this.options.selector).addClass('cmd-interface');
  
      this.container = $('<div/>')
      .addClass('cmd-container')
      .appendTo(this.wrapper);
  
      if (this.options.filedrop_enabled) {
        this.setupFiledrop(''); // adds dropzone div
      }
  
      this.clearScreen(); // adds output, input and prompt
  
      $(this.options.selector).on('click', $.proxy(this.focusOnInput, this));
      $(window).resize($.proxy(this.resizeInput, this));
  
      this.wrapper.keydown($.proxy(this.handleKeyDown, this));
      this.wrapper.keyup($.proxy(this.handleKeyUp, this));
      this.wrapper.keypress($.proxy(this.handleKeyPress, this));

      let self = this;
      this.wrapper.find('.cmd-output').on('click', function(e) {
        e.stopPropagation();
        let selectionTxt = window.getSelection().toString();
        if (!selectionTxt) {
          if (self.input.attr('disabled') == 'disabled') {
            self.enableInput();
          }
          self.focusOnInput();
        }
      })
    }
  
    /**
     * Changes the input type
     */
    TerminalWin.prototype.showInputType = function(input_type) {
      switch (input_type) {
        case 'password':
          this.input = $('<input/>')
            .attr('type', 'password')
            .attr('maxlength', 512)
            .addClass('cmd-in');
          break;
        case 'input':
          this.input = $('<input/>')
            .attr('type', 'text')
            .attr('maxlength', 512)
            .addClass('cmd-in');
        case 'textarea':
            this.input = $('<textarea/>')
            .addClass('cmd-in');
        default:
          this.input = $('<textarea/>')
            .addClass('cmd-in')
          this.input.off("input");
          this.input.off("focus");
          break;
      }

      this.container.children('.cmd-in').remove();
      
      this.input.appendTo(this.container).attr('title', 'Terminal input');
      this.input.txtaAutoHeight();

      
      this.resizeInput();
      // this.focusOnInput();
    }

    TerminalWin.prototype.getErrorOutput = function(cmd_out) {
      return '<span class="red_highlight"> Error: '+cmd_out+'</span>';
    }

    TerminalWin.prototype.displayErrorOutput = function(cmd_out) {
      this.displayOutput(this.getErrorOutput(cmd_out))
    }
  
    /**
     * Takes the client's input and the server's output
     * and displays them appropriately.
     *
     * @param   string  cmd_in      The command as entered by the user
     * @param   string  cmd_out     The server output to write to screen
     */
    TerminalWin.prototype.displayOutput = function(cmd_out, encode) {
      switch (typeof cmd_out) {
        case 'object':
          cmd_out = JSON.stringify(cmd_out);
          break;
        case 'string':
        case 'number':
          break;
        default:
          cmd_out = this.getErrorOutput('invalid cmd_out returned. typeof is '+(typeof cmd_out));
      }
      
      if (encode) {
        cmd_out = htmlEncode(cmd_out)
      }
      cmd_out && (this.cmd_output = cmd_out);
      cmd_out && this.output.append('<code>'+cmd_out+'</code>');
  
      if (this.options.talk) {
        this.speakOutput(cmd_out);
      }
  
      this.cmd_stack.reset();
  
      this.input.val(this.autofill).removeAttr('disabled');
  
      this.enableInput();
      this.focusOnInput();
    }
  
    /**
     * Take an input string and output it to the screen
     */
    TerminalWin.prototype.displayInput = function(cmd_in) {
      cmd_in = cmd_in.replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
  
      this.output.append('<div><span class="prompt">' + this.prompt_str + '</span> ' +
        '<span class="grey_text">' + cmd_in + '</span></div>');
    }
  
    /**
     * Set the prompt string
     * @param {string} new_prompt The new prompt string
     */
    TerminalWin.prototype.setPrompt = function(new_prompt) {
      if (typeof new_prompt !== 'string') {
        throw 'Cmd error: invalid prompt string.';
      }
  
      this.prompt_str = new_prompt;
      this.prompt_elem.html(this.prompt_str);
    }

    TerminalWin.prototype.validator = function(command_name) {
      if (this.all_commands.hasOwnProperty(command_name)) {
        if (location.href.startsWith('chrome-extension://')) {
          if (typeof this.all_commands[command_name] == 'string' || command_name == 'js') {
            throw "You can only exec this command at the normal url page, can not exec js at the extension pages.";
          }
        }
      } else {
        throw "Unrecognised command "+command_name+".";
      }
    }
  
    /**
     * Post-file-drop dropzone reset
     */
    TerminalWin.prototype.resetDropzone = function() {
      dropzone.css('display', 'none');
    }
  
    /**
     * Add file drop handlers
     */
    TerminalWin.prototype.setupFiledrop = function(wrapper) {
      this.dropzone = $('<div/>')
      .addClass('dropzone')
      .appendTo(wrapper)
      .filedrop({
        url: this.options.file_upload_url,
        paramname: 'dropfile', // POST parameter name used on serverside to reference file
        maxfiles: 10,
        maxfilesize: 2, // MBs
        error: function (err, file) {
          switch (err) {
          case 'BrowserNotSupported':
            alert('Your browser does not support html5 drag and drop.');
            break;
          case 'TooManyFiles':
            this.displayInput('[File Upload]');
            this.displayOutput('Too many files!');
            this.resetDropzone();
            break;
          case 'FileTooLarge':
            // FileTooLarge also has access to the file which was too large
            // use file.name to reference the filename of the culprit file
            this.displayInput('[File Upload]');
            this.displayOutput('File too big!');
            this.resetDropzone();
            break;
          default:
            this.displayInput('[File Upload]');
            this.displayOutput('Fail D:');
            this.resetDropzone();
            break;
          }
        },
        dragOver: function () { // user dragging files over #dropzone
          this.dropzone.css('display', 'block');
        },
        dragLeave: function () { // user dragging files out of #dropzone
          this.resetDropzone();
        },
        docOver: function () { // user dragging files anywhere inside the browser document window
          this.dropzone.css('display', 'block');
        },
        docLeave: function () { // user dragging files out of the browser document window
          this.resetDropzone();
        },
        drop: function () { // user drops file
          this.dropzone.append('<br>File dropped.');
        },
        uploadStarted: function (i, file, len) {
          this.dropzone.append('<br>Upload started...');
          // a file began uploading
          // i = index => 0, 1, 2, 3, 4 etc
          // file is the actual file of the index
          // len = total files user dropped
        },
        uploadFinished: function (i, file, response, time) {
          // response is the data you got back from server in JSON format.
          if (response.error !== '') {
            upload_error = response.error;
          }
          this.dropzone.append('<br>Upload finished! ' + response.result);
        },
        progressUpdated: function (i, file, progress) {
          // this function is used for large files and updates intermittently
          // progress is the integer value of file being uploaded percentage to completion
          this.dropzone.append('<br>File uploading...');
        },
        speedUpdated: function (i, file, speed) { // speed in kb/s
          this.dropzone.append('<br>Upload speed: ' + speed);
        },
        afterAll: function () {
          // runs after all files have been uploaded or otherwise dealt with
          if (upload_error !== '') {
            this.displayInput('[File Upload]');
            this.displayOutput('Error: ' + upload_error);
          } else {
            this.displayInput('[File Upload]');
            this.displayOutput('[File Upload]', 'Success!');
          }
  
          upload_error = '';
  
          this.dropzone.css('display', 'none');
          this.resetDropzone();
        }
      });
    }
  
    /**
     * [invert description]
     * @return {[type]} [description]
     */
    TerminalWin.prototype.invert = function() {
      this.wrapper.toggleClass('inverted');
    }
  
  
  
    // ====== Handlers ==============================

    /**
     * Do something
     */
    TerminalWin.prototype.handleInput = function(input_str, from_remote) {
      var self = this;
      if (input_str) {
        try {
          self.pipelineSeriesCommands(self.splitCommands(input_str), from_remote);
        } catch (err) {
          self.displayOutput(err);
        }
      } else {
        self.displayInput('');
        self.displayOutput('');
      }
    }

    TerminalWin.prototype.pipelineSeriesCommands = function(command_list, from_remote) {
      var self = this;
      var serialExec = function(output, i) {
        // console.log("command:", command_list);
        if (i < command_list.length) {
          (new Promise(function (resolve, reject) {
            self.feed_data = output;
            self.ExecCommands(command_list[i], from_remote);
            // 等待命令返回结果
            var times = 0;
            var intervalHandle = setInterval(function() {
              times++;
              // console.log("set interval: ================");
              if (self.cmd_output != -1 || times/10 >= self.timeout) {
                // console.log("clearInterval: ================", self.cmd_output);
                clearInterval(intervalHandle);
                resolve(self.cmd_output);
              }
            }, 100);
          })).then(function(result) {
            serialExec(result, ++i);
          });
        }
      }

      var i = 0;
      serialExec(null, i);
    }

    TerminalWin.prototype.pipelineParallelCommands = function(command_list, from_remote) {
      for (var i in command_list) {
        this.ExecCommands(command_list[i], from_remote);
      }
    }

    TerminalWin.prototype.ExecCommands = function(command_line, from_remote) {
      var self = this;
      var command = new Command(command_line, self.prompt_str);
      self.cmd_output = -1;
      command.Exec(self, from_remote, function(result) {
        self.displayOutput(self.formateOutput(result, from_remote));
      });
    }

    TerminalWin.prototype.splitCommands = function(input_str) {
      let command_list = [];
      let quote = "";

      for (let i=0; i<input_str.length; i++) {
        let chr = input_str.charAt(i);
        if (chr == '"' || chr == "'" || chr == "`") {
          // 如果是开头，则开始对字符串进行包裹
          if (!quote) {
            quote = chr;
          } else if (quote && quote == chr && input_str.charCodeAt(i-1) != 92) {  // 如果是结尾
            quote = "";
          }
        } else if (!quote && chr == '|') {
          command_list.push(input_str.substr(0, i));
          return command_list.concat(this.splitCommands(input_str.substring(i+1)));
        }
      }
      if (input_str.trim()) {
        command_list.push(input_str);
      }
      return command_list;
    }

    TerminalWin.prototype.formateOutput = function(result, from_remote) {
      var self = this;
      let output = ''
      if (result && result.hasOwnProperty('type')) {
        let data = result.hasOwnProperty('data') ? result.data : [];
        switch (result.type) {
            case 'data-list':
              if (data && typeof data == 'object') {
                for (let i in data) {
                  let item = data[i];
                  let img = '';
                  if (item.hasOwnProperty('icon')) {
                    if (item.hasOwnProperty('icon_type') == 'svg') {
                      img = item.icon;
                    } else {
                      img = '<img style="max-width:12px;max-height:12px;margin:-1px 10px;" src="'+item.icon+'"/>';
                    }
                  }
                  if (!item.hasOwnProperty('url')) {
                    output += '<div><label>'+img+item.title+'</label></div>';
                  } else {
                    output += '<div><a href="'+item.url+'" target="_blank">'+img+item.title+'</a></div>';
                  }
                }
              }
              break;
            case 'html-text':  
              output = result.data;
              break;
            case 'command-list':
              if (!from_remote && data && typeof data == 'object' && data.length > 0) {
                self.pipelineSeriesCommands(data, from_remote);
              }
              return output;
        }
      } else if (result) {
        output = result;
      }
      return output
  }
  
    /**
     * Handle JSON responses. Used as callback by external command handler
     * @param  {object} res Chimpcom command object
     */
    TerminalWin.prototype.handleResponse = function(res) {
      if (res.redirect !== undefined) {
        document.location.href = res.redirect;
      }
  
      if (res.openWindow !== undefined) {
        window.open(res.openWindow, '_blank', res.openWindowSpecs);
      }
  
      if (res.log !== undefined && res.log !== '') {
        console.log(res.log);
      }
  
      if (res.show_pass === true) {
        this.showInputType('password');
      } else {
        this.showInputType();
      }
  
      this.displayOutput(res.cmd_out);
  
      if (res.cmd_fill !== '') {
        this.wrapper.children('.cmd-container').children('.cmd-in').first().val(res.cmd_fill);
      }
    }
  
    /**
     * Handle keypresses
     */
    TerminalWin.prototype.handleKeyDown = function(e) {
      var keyCode = e.keyCode || e.which,
      input_str = this.input.val();
      e.stopPropagation();
      if ($.inArray(keyCode, this.keys_array) > -1) {
        e.preventDefault();
      }

      if (keyCode === 9) { //tab
        this.tabComplete(input_str);
      } else if (e.ctrlKey && keyCode == 67) {
        this.displayInput(input_str+"^C");
        return false;
      } else {
        if (keyCode === 13) { // enter
          this.autofill = '';
          if (input_str.charCodeAt(input_str.length-1) === 92) {
            input_str = input_str.substr(0, input_str.length-1)+"\n";
            this.input.val(input_str);
            this.focusOnInput();
          } else {
            if (this.input.attr('disabled')) {
              return false;
            }
    
            if (e.ctrlKey) {
              this.cmd_stack.push(input_str);
              if (isURL(input_str)) {
                this.goToURL(input_str);
              } else {
                this.handleInput("search "+input_str);
              }
            } else {
              this.disableInput();
              // push command to stack if using text input, i.e. no passwords
              if (this.input.get(0).type !== 'password' && input_str) {
                this.cmd_stack.push(input_str);
              }
    
              this.handleInput(input_str);
            }
          }
          
        } else if (keyCode === 38) { // up arrow
          if (input_str !== "" && this.cmd_stack.getCur() === this.cmd_stack.getSize()) {
            this.cmd_stack.push(input_str);
          }
  
          this.input.val(this.cmd_stack.prev());
          this.resizeInput();
        } else if (keyCode === 40) { // down arrow
          this.input.val(this.cmd_stack.next());
          this.resizeInput();
        } else if (keyCode === 27) { // esc
          // this.options.selector.toggle();
        }
      }
    }

    /**
     * Prevent default action of special keys
     */
    TerminalWin.prototype.handleKeyUp = function(e) {
      var key = e.keyCode || e.which;
      if (key != 91 && key != 17) {
        e.stopPropagation();
      }

      if ($.inArray(key, this.keys_array) > -1) {
        e.preventDefault();
        return false;
      }
      return true;
    }
  
    /**
     * Prevent default action of special keys
     */
    TerminalWin.prototype.handleKeyPress = function(e) {
      var key = e.keyCode || e.which;
      e.stopPropagation();
      // if ($.inArray(key, this.keys_array) > -1) {
      //   e.preventDefault();
      //   return false;
      // }
      return true;
    }
  
    /**
     * Complete command names when tab is pressed
     */
    TerminalWin.prototype.tabComplete = function(input_str, from_remote) {
      let self = this;
      self.tab_nums++;
      setTimeout(function() {
        self.tab_nums = 0;
      }, 300);

      var command = new Command(input_str, this.prompt_str);
      var message = {};

      if (self.tab_nums == 1) {
        command.TabCompleteSystem(self);
      } else if (self.tab_nums == 2) {
        message = command.TabComplete(self, from_remote);
        if (!from_remote) {
          self.displayOutput(self.formateOutput(message, from_remote));
        }
        self.input.val(input_str);
      }

      
      return message;
    }
  
  
    // ====== Helpers ===============================
  
    /**
     * Takes a user to a given url. Adds "http://" if necessary.
     */
    TerminalWin.prototype.goToURL = function(url) {
      if (!isURL(url)) {
        // this.displayOutput("please type valid url address.");
        // return
      }
      if (url.substr(0, 4) !== 'http' && url.substr(0, 2) !== '//') {
        url = 'http://' + url;
      }
  
      if (this.popup) {
        window.open(url, '_blank');
        window.focus();
      } else {
        // break out of iframe - used by chrome plugin
        if (top.location !== location) {
          top.location.href = document.location.href;
        }
  
        location.href = url;
      }
    }
  
    /**
     * Give focus to the command input and
     * scroll to the bottom of the page
     */
    TerminalWin.prototype.focusOnInput = function() {
      $(this.options.selector).scrollTop($(this.options.selector)[0].scrollHeight);
      this.input.focus();
    }
  
    /**
     * Make prompt and input fit on one line
     */
    TerminalWin.prototype.resizeInput = function() {
      var cmd_width = this.wrapper.width() - this.wrapper.find('.main-prompt').first().width() - 25 - 10;
      this.input.css('width', cmd_width);
      this.focusOnInput();
    }
  
    /**
     * Clear the screen
     */
    TerminalWin.prototype.clearScreen = function() {
      this.container.empty();
  
      this.output = $('<div/>')
        .addClass('cmd-output')
        .append(this.output_init)
        .appendTo(this.container);
  
      this.prompt_elem = $('<span/>')
        .addClass('main-prompt')
        .addClass('prompt')
        .html(this.prompt_str)
        .appendTo(this.container);
  
      this.showInputType();
  
      this.input.val(this.autofill);
    }
  
    /**
     * Temporarily disable input while runnign commands
     */
    TerminalWin.prototype.disableInput = function() {
      this.input
        .attr('disabled', true)
        .val(this.options.busy_text);
    }
  
    /**
     * Reenable input after running disableInput()
     */
    TerminalWin.prototype.enableInput = function() {
      this.input
        .removeAttr('disabled')
        .val(this.autofill);
    }
  
    /**
     * Speak output aloud using speech synthesis API
     *
     * @param {String} output Text to read
     */
    TerminalWin.prototype.speakOutput = function(output) {
      var msg = new SpeechSynthesisUtterance();
  
      msg.volume = 1; // 0 - 1
      msg.rate   = 1; // 0.1 - 10
      msg.pitch  = 2; // 0 - 2
      msg.lang   = 'en';
      msg.text   = $('<code>'+output+'</code>').text();
  
      window.speechSynthesis.speak(msg);
    }
  
    return TerminalWin;
  }));
  