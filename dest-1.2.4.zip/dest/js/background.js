var CmdHub = {};
function message_cmdhub(message, sender, callback) {
    let meta = {code: 200, msg: "", data: []};
    switch (message.method) {
        case 'get_cmdhub':
            meta.data = CmdHub;
            api_send_callback_message(sender, message, {meta: meta});
        break;
        case 'add':
            newCmd = message.newCmd;
            if (CmdHub.hasOwnProperty(newCmd)) {
                meta.code = 300;
                meta.msg = 'The command '+newCmd+' has exist.';
                api_send_callback_message(sender, message, {meta: meta});
            } else {
                cmdhub_get_cmd_code(newCmd, function(meta, config, code) {
                    cmdhub_update_all_tabs_cmd(newCmd);
                    api_send_callback_message(sender, message, {meta: meta});
                }, function(meta) {
                    api_send_callback_message(sender, message, {meta: meta});
                });
            }
            
        break;
        case 'update':
            newCmd = message.newCmd;
            cmdhub_get_cmd_code(newCmd, function(meta, config, code) {
                cmdhub_update_all_tabs_cmd(newCmd);
                api_send_callback_message(sender, message, {meta: meta});
            }, function(meta) {
                api_send_callback_message(sender, message, {meta: meta});
            });
        break;
        case 'delete':
            newCmd = message.newCmd;
            delete CmdHub[newCmd];
            api_storage_sync_set({'cmd:hub': CmdHub});
            meta.data = CmdHub;
            api_send_callback_message(sender, message, {meta: meta});
        break;
        case 'custom':
            if (message.hasOwnProperty('newCmd') && message.hasOwnProperty('cmdContent')) {
                let cmdset = {};
                newCmd = message.newCmd;
                cmdset['cmd:code:'+newCmd] = message.cmdContent;
                CmdHub[newCmd] = {
                    version: '1.0.0',
                    site: '*',
                    index_func: newCmd+'Cmd' ,
                }
                api_storage_sync_set({'cmd:hub': CmdHub});
                api_storage_local_set(cmdset);
                cmdhub_update_all_tabs_cmd(newCmd);
                meta.data = CmdHub;
                api_send_callback_message(sender, message, {meta: meta});
            }
        break;
    }
}

function cmdhub_get_cmd_code(newCmd, successCallback, errorCallback) {
    let cmdhub_prefix = 'https://raw.githubusercontent.com/web-terminal/cmdhub/master/';
    let cmdhub_source_prefix = 'https://github.com/web-terminal/cmdhub/blob/master/';
    let meta = {code: 200, msg: "", data: []};
    $.ajax({
        url: cmdhub_prefix+newCmd+'/cmd.json',
        type: 'GET',
        async: true,
        dataType: 'json',
        success: function(jsonData) {
            if (jsonData.hasOwnProperty('version')) {
                let mainFile = jsonData.hasOwnProperty('main') ? jsonData.main : 'main.js';
                // get main file
                $.ajax({
                    url: cmdhub_prefix+newCmd+'/'+mainFile,
                    type: 'GET',
                    async: true,
                    dataType: 'text',
                    success: function(jsFile) {
                        let cmdset = {}
                        cmdset['cmd:code:'+newCmd] = jsFile;
                        CmdHub[newCmd] = {
                            version: jsonData.version,
                            site: jsonData.hasOwnProperty('site') ? jsonData.site : '',
                            index_func: jsonData.index_func ,
                        }

                        api_storage_sync_set({'cmd:hub': CmdHub});
                        api_storage_local_set(cmdset);
                        meta.data = CmdHub;
                        successCallback && successCallback(meta, jsonData, cmdset['cmd:code:'+newCmd]);
                    },
                    error: function(xhr) {
                        meta.code = 500;
                        meta.msg = 'Get code error. please check you have visit url <a href="'+cmdhub_source_prefix+newCmd+'/'+mainFile+'">'+cmdhub_source_prefix+newCmd+'/'+mainFile+'</a>';
                        errorCallback && errorCallback(meta, jsonData);
                    }
                });
            } else {
                meta.code = 500;
                meta.msg = 'Invalid command config, unknown command version.';
                errorCallback && errorCallback(meta, jsonData);
            }
        },
        error: function(xhr) {
            meta.code = 500;
            meta.msg = 'Please verify that this command is in the <a target="_blank" href="https://github.com/web-terminal/cmdhub">cmdhub</a> repository.';
            errorCallback && errorCallback(meta, null);
        }
    });
}

function cmdhub_update_all_tabs_cmd(cmd) {
    api_tab_query({}, function(tabs) {
        for (let i in tabs) {
            if (tabs[i].url.startsWith('http')) {
                cmdhub_inject_cmd(cmd, tabs[i].id);
            }
        }
    });
}

function cmdhub_inject_cmd(cmd, tabId, callback, error) {
    let cmd_storage_key = 'cmd:code:'+cmd;
    try {
        api_storage_local_get(cmd_storage_key, function(res) {
            if (res && res.hasOwnProperty(cmd_storage_key)) {
                api_execute_script(tabId, {code: res[cmd_storage_key]}, callback);
            } else {
                cmdhub_get_cmd_code(newCmd, function(meta, config, code) {
                    api_execute_script(tabId, {code: code}, callback);
                });
            }
        });
    } catch (e) {
        typeof error == 'function' && error(e);
    }
    
}

function cmdhub_init(tabId) {
    api_storage_sync_get(['cmd:hub'], function(res) {
        if (res && res.hasOwnProperty('cmd:hub')) {
            CmdHub = res['cmd:hub'];
            for (let cmd in CmdHub) {
                cmdhub_inject_cmd(cmd, tabId);
            }
        }
    });
    
}

function cmdhub_listen_tab_loading_event(tabId, changeInfo, tab) {
    if (changeInfo.hasOwnProperty('status') && changeInfo.status == 'loading' && tab.url.startsWith('http')) {
        cmdhub_init(tabId)
    }
}
// 初始化cron
var cronJobStacks = {};
var cronJobMaps = {};
api_storage_sync_get("cron-jobs", function(results) {
    if (results.hasOwnProperty("cron-jobs")) {
        cronJobMaps = results["cron-jobs"];
        for (let id in cronJobMaps) {
            if (cronJobMaps[id].enabled) {
                cronItemRunStart(cronJobMaps[id]);
            }
        }
    }
});

function addCronItem(taburl, options) {
    // 对url去除锚点
    let archPos = taburl.indexOf('#');
    if (taburl.indexOf('#') > 0) {
        taburl = taburl.substring(0, archPos)
    }
    let item = {
        id: getUID(),
        rule: options.rule,
        cmds: options.cmds,
        url: taburl,
        openType: options.hasOwnProperty('openType') ? options.openType : "auto-open",  // auto-open, open-only 
        showType: options.hasOwnProperty('showType') ? options.showType : "frontend", // background, frontend
        enabled: true,  // true, false
        times: 0
    }
    cronJobMaps[item.id] = item;
    cronItemRunStart(item);
    api_storage_sync_set({"cron-jobs": cronJobMaps});
}
function updateCronItem(options) {
    if (options.hasOwnProperty('id') && cronJobMaps.hasOwnProperty(options.id)) {
        let id = options.id;
        if (options.hasOwnProperty('rule')) {
            cronJobMaps[id]['rule'] = options.rule;
            cronItemRunStop(cronJobMaps[id]);
            if (!options.hasOwnProperty('enabled'))
                options['enabled'] = cronJobMaps[id]['enabled'];
        }
        if (options.hasOwnProperty('cmds')) cronJobMaps[id]['cmds'] = options.cmds;
        if (options.hasOwnProperty('showType')) cronJobMaps[id]['showType'] = options.showType;
        if (options.hasOwnProperty('openType')) cronJobMaps[id]['openType'] = options.openType;
        if (options.hasOwnProperty('enabled')) {
            cronJobMaps[id]['enabled'] = options.enabled;
            if (options.enabled) {
                cronItemRunStart(cronJobMaps[id]);
            } else {
                cronItemRunStop(cronJobMaps[id]);
            }
        }
        api_storage_sync_set({"cron-jobs": cronJobMaps});
    }
}
function removeCronItem(options) {
    if (options.hasOwnProperty('id')) {
        cronItemRunStop(cronJobMaps[options.id]);
        delete cronJobMaps[options.id];
        api_storage_sync_set({"cron-jobs": cronJobMaps});
    }
}
function cronItemRunStart(item) {
    if (!item.enabled || cronJobStacks.hasOwnProperty(item.id)) return false;
    cronJobStacks[item.id] = {};
    try {
        let openTabToConnect = function(tab) {
            if (!tab) {
                if (item.openType != "open-only") {
                    api_tab_create(item.url, function(tab) {
                        cronJobStacks[item.id]['tab'] = tab;
                        waitTabComplete(tab, 300, function(tab) {
                            item.times++;
                            api_send_tab_message(tab.id, {type: "remote-command-run", item: item}, function(response) {
                                if (item.openType == "finished-close") {
                                    api_tab_remove(tab.id);
                                }
                            })
                        });
                    });
                }
            } else {
                // console.log("api_send_tab_message", tab, {type: "remote-command-run", item: item});
                item.times++;
                api_send_tab_message(tab.id, {type: "remote-command-run", item: item})
            }
        }

        cronJobStacks[item.id]['job'] = new CronJob(item.rule, function() {
            if (cronJobStacks[item.id].hasOwnProperty('tab')) {
                api_tab_get(cronJobStacks[item.id].tab.id, function(tab) {
                    openTabToConnect(tab);
                });
            } else {
                api_tab_query({url: item.url}, function(tabs) {
                    openTabToConnect(tabs && tabs.length > 0 ? tabs[0] : null);
                });
            }
        });
    } catch (error) {
        console.log(error)
    }
}

function cronItemRunStop(item) {
    if (cronJobStacks.hasOwnProperty(item.id) && cronJobStacks[item.id].hasOwnProperty('job')) {
        cronJobStacks[item.id]['job'].Stop();
        item.enabled = false;
        delete cronJobStacks[item.id];
    }
}
var tabChan = {};
var responseChan = {};
function response_chan_set(messageId, response) {
    if (!responseChan.hasOwnProperty(messageId)) responseChan[messageId] = [];
    responseChan[messageId].push() ;
    let messageIds = Object.keys(responseChan);
    if (messageIds.length > 50) delete responseChan[messageIds[0]];
}
function response_chan_get() {

}

// 监听注入页面事件
api_runtime_on_message_listener(function(message, sender, callback) {
    switch (message.type) {
    case "js":
    case "selector":
        let sendMessage = function(tab) {
            if (message.type == 'js') {
                let content = (message.feed_data ? "var TerminalFeedArgs="+message.feed_data+";" : '')+message.content.join('')
                api_execute_script(tab.id, {code: content}, function(result) {
                    for (let i in result) {
                        let callbackMessage = message;
                        callbackMessage['response'] = JSON.stringify(result[i]);
                        api_send_callback_message(sender, message, callbackMessage);
                    }
                });
            } else {
                api_send_tab_message(tab.id, message, function(response) {
                    response_chan_set(message['UID'], response);
                    let callbackMessage = message;
                    callbackMessage['response'] = response;
                    api_send_callback_message(sender, message, callbackMessage);
                });
            }
        }
        if (message.options.hasOwnProperty('url')) {
            if (message.options.url.indexOf("TerminalFeedArgs") > -1) {
                var feed_data = message.feed_data ? message.feed_data.slice(1, -1) : '';
                message.options.url = message.options.url.replace("TerminalFeedArgs", feed_data);
            }
            if (!tabChan.hasOwnProperty(message.options.url)) {
                api_tab_create({url: message.options.url, active: message.options.hasOwnProperty('active_tab') ? message.options.active_tab : true}, function(tab) {
                    tabChan[message.options.url] = tab;
                    waitTabComplete(tab, 300, sendMessage);
                });
            } else {
                api_tab_get(tabChan[message.options.url].id, function(tab) {
                    if (!tab) {
                        api_tab_create({url: message.options.url, active: message.options.hasOwnProperty('active_tab') ? message.options.active_tab : true}, function(tab) {
                            tabChan[message.options.url] = tab;
                            waitTabComplete(tab, 300, sendMessage);
                        });
                    } else {
                        // active tab
                        api_tab_update(tab.id, {active: message.options.hasOwnProperty('active_tab') ? message.options.active_tab : true})
                        sendMessage(tab);
                    }
                });
            }
        } else {
            sendMessage(sender.tab);
        }
    break;
    case "ajax-request":
        if (message.hasOwnProperty('config')) {
            message.config['complete'] = function(xhr, ts) {
                api_send_callback_message(sender, message, {
                    data: {
                        xhr: xhr,
                        ts: ts
                    }
                });
            }
            $.ajax(message.config);
        }
    break;
    case "browser-notifications":
        api_notifications_create(message.options, function(result) {
            api_send_callback_message(sender, message, {
                data: result
            });
        });
    break;
    case "browser-tabs":
        if (message.options.type == 'query') {
            api_tab_query(message.options.query, function(tabs) {
                api_send_callback_message(sender, message, {
                    data: tabs
                });
            });
        } else if (message.options.type == 'update') {
            api_tab_update(message.options.tabId, message.options.updateProperties, function(tab) {
                api_send_callback_message(sender, message, {
                    data: tab
                });
            });
        }
        
    break;
    case "browser-bookmarks":
        if (message.options.type == 'query') {
            api_bookmark_query(message.options.query, function(results) {
                api_send_callback_message(sender, message, {
                    data: results
                });
            });
        } else if (message.options.type == 'getRecent') {
            api_bookmark_getRecent(message.options.numberOfItems, function(results) {
                api_send_callback_message(sender, message, {
                    data: results
                });
            });
        }
    break;
    case "browser-history":
        api_history_query(message.options, function(results) {
            api_send_callback_message(sender, message, {
                data: results
            });
        });
    break;
    case "cron-job":
        let returnMessage = {data: 'ok'};
        if (message.options.type == 'list') {
            returnMessage.data = cronJobMaps;
        } else if (message.options.type == 'add') {
            addCronItem(sender.tab.url, message.options);
        } else if (message.options.type == 'delete') {
            removeCronItem(message.options);
        } else if (message.options.type == 'update') {
            updateCronItem(message.options)
        }
        api_send_callback_message(sender, message, returnMessage);
    break;
    case "exec-remote-command":
        var config = message.config;
        api_tab_query({url: config.hasOwnProperty('match_url') ? config.match_url : message.site}, function(tabs) {
            if (tabs && tabs.length > 0) {
                var tab = [];
                for (let i in tabs) {
                    tab = tabs[i];
                    api_send_tab_message(tabs[i].id, {type: "remote-command-run", item: message.item}, function(result) {
                        api_send_callback_message(sender, message, {'data': result});
                    });
                    if (!config.hasOwnProperty('exec_all_match_url') || !config.exec_all_match_url) break;
                }
                if (config.hasOwnProperty('active_url') && config.active_url) api_tab_update(tab.id, {active: true});
            } else {
                if (config.hasOwnProperty('auto_open') && config.auto_open) {
                    api_tab_create({url: message.site, active: config.hasOwnProperty('active_url') ? config.active_url : true}, function(tab) {
                        waitTabComplete(tab, 300, function(tab) {
                            api_send_tab_message(tab.id, {type: "remote-command-run", item: message.item}, function(result) {
                                api_send_callback_message(sender, message, {'data': result});
                            });
                        });
                    });
                }
            }
            
        });
    break;
    case "exec-remote-tab":
        var config = message.config;
        api_tab_query({url: config.hasOwnProperty('match_url') ? config.match_url : config.site}, function(tabs) {
            if (tabs && tabs.length > 0) {
                for (let i in tabs) {
                    console.log(tabs[i].id)
                    api_send_tab_message(tabs[i].id, {type: "remote-tab-run", item: message.item}, function(result) {
                        api_send_callback_message(sender, message, {'data': result});
                    });
                    break;
                }
            } else {
                if (config.hasOwnProperty('auto_open') && config.auto_open) {
                    api_tab_create({url: config.site, active: config.hasOwnProperty('active_url') ? config.active_url : true}, function(tab) {
                        waitTabComplete(tab, 300, function(tab) {
                            api_send_tab_message(tab.id, {type: "remote-tab-run", item: message.item}, function(result) {
                                api_send_callback_message(sender, message, {'data': result});
                            });
                        });
                    });
                }
            }
            
        });
    break;
    case "cmdhub":
        message_cmdhub(message, sender, callback);
    break;
    }
});

// var storageChangesListenerMessageChannel = {}
// var storageChangesListener = {}
// api_storage_on_change_listener(function(changes, areaName) {
//     for (let key in changes) {
//         if (storageChangesListenerMessageChannel.hasOwnProperty(key)) {
//             storageChangesListenerMessageChannel[key]
//             api_send_tab_message(
//                 storageChangesListenerMessageChannel[key][tab]['id'],
//                 changes[key]['newValue'],
//                 info => {
//                     console.log("selector response:", info)
//                     // callback(info)
//                 }
//             )
//             delete storageChangesListenerMessageChannel[key];
//         } else if (storageChangesListener.hasOwnProperty(key)) {
//             storageChangesListener[key](changes[key]['newValue'], changes[key]['oldValue']);
//         }
//     }
// });

// listener 
api_tab_onupdated(function(tabId, changeInfo, tab) {
    cmdhub_listen_tab_loading_event(tabId, changeInfo, tab);
});

// listener key code event
chrome.commands.onCommand.addListener(function(command) {
    // console.log('Command:', command);
    if (command == "toggle-cmdwin") {
        api_tab_current(function(tabs) {
            try {
                // console.log(tabs);
                api_send_tab_message(
                    tabs[0].id,
                    {type: 'toggleCmdWin'},
                    info => {
                        if (info == undefined) {
                            api_tab_create('/main.html');
                        }
                        // console.log("callback", info)
                    }
                )
            } catch (error) {
                console.log(error)
            }
        });
    }
});

function waitTabComplete(tab, timeout, callback) {
    if (tab.status == 'loading') {
        setTimeout(() => {
            api_tab_get(tab.id, (tab) => {
                waitTabComplete(tab, timeout+500, callback)
            });
        }, timeout);
    } else if (tab.status == 'complete') {
        callback(tab)
    }
}